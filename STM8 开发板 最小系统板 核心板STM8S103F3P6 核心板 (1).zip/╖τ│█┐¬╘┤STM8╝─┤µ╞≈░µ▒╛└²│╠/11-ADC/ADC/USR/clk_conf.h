#ifndef __CLK_CONF_H
#define __CLK_CONF_H

#include "type_def.h"
void Clk_conf(void);
#endif

